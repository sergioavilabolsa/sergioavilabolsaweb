<?php
/**
 * Minimal and safe automation settings bridge.
 *
 * @package SergioPremium
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize webhook URL safely.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function sergiopremium_sanitize_webhook_url( $value ) {
	if ( ! is_string( $value ) ) {
		return '';
	}

	$value = trim( $value );
	if ( '' === $value ) {
		return '';
	}

	return esc_url_raw( $value );
}

/**
 * Register settings.
 */
function sergiopremium_register_automation_settings() {
	register_setting(
		'sergiopremium_automation',
		'sergiopremium_automation_webhook_url',
		array(
			'type'              => 'string',
			'sanitize_callback' => 'sergiopremium_sanitize_webhook_url',
			'default'           => '',
		)
	);
}
add_action( 'admin_init', 'sergiopremium_register_automation_settings' );

/**
 * Add settings page.
 */
function sergiopremium_add_automation_settings_page() {
	add_options_page(
		'Automatizacion Mercado',
		'Automatizacion Mercado',
		'manage_options',
		'sergiopremium-automation',
		'sergiopremium_render_automation_settings_page'
	);
}
add_action( 'admin_menu', 'sergiopremium_add_automation_settings_page' );

/**
 * Render settings page.
 */
function sergiopremium_render_automation_settings_page() {
	$value = (string) get_option( 'sergiopremium_automation_webhook_url', '' );
	$notice = get_transient( 'sergiopremium_automation_test_notice' );
	if ( false !== $notice ) {
		delete_transient( 'sergiopremium_automation_test_notice' );
	}
	?>
	<div class="wrap">
		<h1>Automatizacion de Mercado</h1>
		<p>Pega aqui la URL de webhook de n8n para enlazar WordPress con tu automatizacion.</p>
		<?php if ( is_array( $notice ) && isset( $notice['type'], $notice['message'] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'sergiopremium_automation' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="sergiopremium_automation_webhook_url">Webhook URL</label></th>
					<td>
						<input
							type="url"
							class="regular-text"
							id="sergiopremium_automation_webhook_url"
							name="sergiopremium_automation_webhook_url"
							value="<?php echo esc_attr( $value ); ?>"
							placeholder="https://n8n.tudominio.com/webhook/sergio-market-automation"
						/>
						<p class="description">Ejemplo: https://n8n.srvXXXX.hstgr.cloud/webhook/sergio-market-automation</p>
					</td>
				</tr>
			</table>
			<?php submit_button( 'Guardar ajustes' ); ?>
		</form>

		<hr />
		<h2>Prueba de conexion con n8n</h2>
		<p>Este boton envia un payload de prueba al webhook configurado para validar conectividad.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="sergiopremium_test_webhook" />
			<?php wp_nonce_field( 'sergiopremium_test_webhook_action', 'sergiopremium_test_webhook_nonce' ); ?>
			<?php submit_button( 'Probar webhook ahora', 'secondary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

/**
 * Handle manual webhook test.
 */
function sergiopremium_handle_test_webhook() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'No autorizado.' );
	}

	check_admin_referer( 'sergiopremium_test_webhook_action', 'sergiopremium_test_webhook_nonce' );

	$webhook_url = trim( (string) get_option( 'sergiopremium_automation_webhook_url', '' ) );
	if ( '' === $webhook_url ) {
		set_transient(
			'sergiopremium_automation_test_notice',
			array(
				'type'    => 'error',
				'message' => 'No hay webhook configurado. Guarda primero una URL valida.',
			),
			60
		);
		wp_safe_redirect( admin_url( 'options-general.php?page=sergiopremium-automation' ) );
		exit;
	}

	$payload = array(
		'event'        => 'manual_test',
		'timestamp'    => gmdate( DATE_ATOM ),
		'site'         => home_url( '/' ),
		'template_key' => 'manual_test',
		'prompt'       => 'Prueba de conexion enviada desde WordPress.',
	);

	$response = wp_remote_post(
		$webhook_url,
		array(
			'timeout' => 20,
			'headers' => array(
				'Content-Type' => 'application/json; charset=utf-8',
			),
			'body'    => wp_json_encode( $payload ),
		)
	);

	if ( is_wp_error( $response ) ) {
		$message = 'Error al llamar al webhook: ' . $response->get_error_message();
		$type    = 'error';
	} else {
		$code    = (int) wp_remote_retrieve_response_code( $response );
		$type    = ( $code >= 200 && $code < 300 ) ? 'success' : 'warning';
		$message = 'Webhook respondio con codigo HTTP ' . $code . '.';
	}

	set_transient(
		'sergiopremium_automation_test_notice',
		array(
			'type'    => $type,
			'message' => $message,
		),
		60
	);

	wp_safe_redirect( admin_url( 'options-general.php?page=sergiopremium-automation' ) );
	exit;
}
add_action( 'admin_post_sergiopremium_test_webhook', 'sergiopremium_handle_test_webhook' );
