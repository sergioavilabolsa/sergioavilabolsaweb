<?php get_header(); ?>

<main>
	<section class="single-header">
		<span class="single-category">Comunidad</span>
		<h1 class="single-title">Redes Sociales</h1>
		<p class="single-meta">Sigue mis analisis y contenidos en cada plataforma</p>
	</section>

	<section class="latest-analysis" style="padding-top: 2rem;">
		<div class="container" style="max-width: 900px;">
			<div class="single-content" style="max-width: 900px;">
				<p>Aqui tienes todos mis canales oficiales para estar al dia de analisis, videos y novedades:</p>
				<ul>
					<li><strong>YouTube:</strong> <a href="https://www.youtube.com/c/sergioavilabolsa" target="_blank" rel="noopener">https://www.youtube.com/c/sergioavilabolsa</a></li>
					<li><strong>X:</strong> <a href="https://x.com/SergioAvila_IG" target="_blank" rel="noopener">https://x.com/SergioAvila_IG</a></li>
					<li><strong>Threads:</strong> <a href="https://www.threads.net/@sergioavilabolsa" target="_blank" rel="noopener">https://www.threads.net/@sergioavilabolsa</a></li>
					<li><strong>Facebook:</strong> <a href="https://www.facebook.com/sergioavilabolsa" target="_blank" rel="noopener">https://www.facebook.com/sergioavilabolsa</a></li>
					<li><strong>Instagram:</strong> <a href="https://www.instagram.com/sergioavilabolsa" target="_blank" rel="noopener">https://www.instagram.com/sergioavilabolsa</a></li>
					<li><strong>TikTok:</strong> <a href="https://www.tiktok.com/@sergioavilabolsa" target="_blank" rel="noopener">https://www.tiktok.com/@sergioavilabolsa</a></li>
					<li><strong>Telegram:</strong> <a href="https://t.me/sergioavila_bolsa" target="_blank" rel="noopener">https://t.me/sergioavila_bolsa</a></li>
				</ul>
			</div>
		</div>
	</section>
</main>

<?php get_footer(); ?>
