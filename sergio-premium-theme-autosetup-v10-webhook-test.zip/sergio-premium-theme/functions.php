<?php
/**
 * Sergio Ávila Premium functions and definitions
 */

$sergiopremium_automation_file = get_template_directory() . '/inc/automation.php';
if ( file_exists( $sergiopremium_automation_file ) ) {
	require_once $sergiopremium_automation_file;
}

if ( ! function_exists( 'sergiopremium_setup' ) ) :
	function sergiopremium_setup() {
		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'sergiopremium' ),
				'footer' => esc_html__( 'Footer Menu', 'sergiopremium' ),
			)
		);

		// Switch default core markup for search form, comment form, and comments to output valid HTML5.
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'sergiopremium_setup' );

/**
 * Enqueue scripts and styles.
 */
function sergiopremium_scripts() {
	// Google Fonts
	wp_enqueue_style( 'sergiopremium-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Outfit:wght@400;600;700&display=swap', array(), null );
	
	// Main Style
	wp_enqueue_style( 'sergiopremium-style', get_stylesheet_uri(), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'sergiopremium_scripts' );

/**
 * Custom excerpt length for automated articles
 */
function sergiopremium_custom_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'sergiopremium_custom_excerpt_length', 999 );

/**
 * Redirect legacy domain traffic to preferred domain.
 * Keeps path/query so old URLs migrate cleanly.
 */
function sergiopremium_redirect_legacy_domains() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	$preferred_domain = 'sergioavilabolsa.es';
	$legacy_domains   = array(
		'sergioavilabolsa.com',
		'www.sergioavilabolsa.com',
		'www.sergioavilabolsa.es',
	);

	$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
	if ( '' === $host ) {
		return;
	}

	if ( in_array( $host, $legacy_domains, true ) ) {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$target_url  = 'https://' . $preferred_domain . $request_uri;
		wp_safe_redirect( $target_url, 301 );
		exit;
	}
}
// Disabled by default to prevent unexpected cross-domain/admin redirects on fresh installs.
// add_action( 'template_redirect', 'sergiopremium_redirect_legacy_domains', 1 );

/**
 * Ensure biography page exists on the new site.
 */
function sergiopremium_ensure_biography_page() {
	$slug = 'biografia-de-sergio-avila-luengo';

	$existing_page = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $existing_page ) {
		return;
	}

	$page_id = wp_insert_post(
		array(
			'post_title'   => 'Biografía de Sergio Ávila Luengo',
			'post_name'    => $slug,
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_content' => 'Página de biografía de Sergio Ávila.',
		),
		true
	);

	if ( ! is_wp_error( $page_id ) ) {
		update_option( 'sergiopremium_biography_page_id', (int) $page_id );
	}
}
add_action( 'init', 'sergiopremium_ensure_biography_page' );

/**
 * Ensure a page exists and return its ID.
 *
 * @param string $slug    Page slug.
 * @param string $title   Page title.
 * @param string $content Optional page content.
 * @return int
 */
function sergiopremium_ensure_page( $slug, $title, $content = '' ) {
	$existing_page = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $existing_page instanceof WP_Post ) {
		return (int) $existing_page->ID;
	}

	$page_id = wp_insert_post(
		array(
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_content' => $content,
		),
		true
	);

	if ( is_wp_error( $page_id ) ) {
		return 0;
	}

	return (int) $page_id;
}

/**
 * Auto-configure front page and navigation after theme activation.
 */
function sergiopremium_run_first_time_setup() {
	$front_page_id = sergiopremium_ensure_page(
		'inicio',
		'Inicio',
		'Esta página se usa como portada del sitio.'
	);
	$blog_page_id  = sergiopremium_ensure_page(
		'blog',
		'Blog',
		'Esta página se usa para listar las entradas.'
	);
	$bio_page_id   = sergiopremium_ensure_page(
		'biografia-de-sergio-avila-luengo',
		'Biografía de Sergio Ávila Luengo',
		'Página de biografía de Sergio Ávila.'
	);
	$social_page_id = sergiopremium_ensure_page(
		'redes-sociales',
		'Redes Sociales',
		'Encuentra todos los canales oficiales de Sergio Ávila.'
	);

	if ( $front_page_id > 0 ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id );
	}

	if ( $blog_page_id > 0 ) {
		update_option( 'page_for_posts', $blog_page_id );
	}

	if ( $bio_page_id > 0 ) {
		update_option( 'sergiopremium_biography_page_id', $bio_page_id );
	}

	$menu_name = 'Menú principal';
	$menu_obj  = wp_get_nav_menu_object( $menu_name );
	$menu_id   = $menu_obj ? (int) $menu_obj->term_id : 0;

	if ( $menu_id <= 0 ) {
		$menu_id = (int) wp_create_nav_menu( $menu_name );
	}

	if ( $menu_id > 0 ) {
		$existing_items = wp_get_nav_menu_items( $menu_id );
		$linked_pages   = array();

		if ( is_array( $existing_items ) ) {
			foreach ( $existing_items as $item ) {
				$linked_pages[] = (int) $item->object_id;
			}
		}

		$pages_for_menu = array( $front_page_id, $blog_page_id, $bio_page_id, $social_page_id );
		foreach ( $pages_for_menu as $page_id ) {
			$page_id = (int) $page_id;
			if ( $page_id <= 0 || in_array( $page_id, $linked_pages, true ) ) {
				continue;
			}

			wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'     => get_the_title( $page_id ),
					'menu-item-object'    => 'page',
					'menu-item-object-id' => $page_id,
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
				)
			);
		}

		$locations             = get_theme_mod( 'nav_menu_locations', array() );
		$locations['menu-1']   = $menu_id;
		$locations['footer']   = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	update_option( 'sergiopremium_setup_completed', 'yes' );
}
// add_action( 'after_switch_theme', 'sergiopremium_run_first_time_setup' );

/**
 * Fallback setup in case activation hook was missed.
 */
function sergiopremium_maybe_run_setup_fallback() {
	if ( 'yes' === get_option( 'sergiopremium_setup_completed' ) ) {
		return;
	}

	sergiopremium_run_first_time_setup();
}
// add_action( 'init', 'sergiopremium_maybe_run_setup_fallback', 20 );

/**
 * Prevent bad URL config that points site to /wp-admin.
 */
function sergiopremium_fix_admin_url_options() {
	$option_keys = array( 'home', 'siteurl' );

	foreach ( $option_keys as $key ) {
		$current = get_option( $key );
		if ( ! is_string( $current ) || '' === $current ) {
			continue;
		}

		$fixed = preg_replace( '#/wp-admin/?$#i', '', $current );
		if ( is_string( $fixed ) && $fixed !== $current ) {
			update_option( $key, untrailingslashit( $fixed ) );
		}
	}
}
// add_action( 'init', 'sergiopremium_fix_admin_url_options', 5 );

/**
 * Keep site URLs aligned with current host root.
 */
function sergiopremium_normalize_site_urls_to_current_host() {
	$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
	if ( '' === $host ) {
		return;
	}

	$scheme = is_ssl() ? 'https://' : 'http://';
	$target = untrailingslashit( $scheme . $host );

	$home    = get_option( 'home' );
	$siteurl = get_option( 'siteurl' );

	if ( is_string( $home ) ) {
		$home_clean = untrailingslashit( preg_replace( '#/wp-admin/?$#i', '', $home ) );
		if ( $home_clean !== $target ) {
			update_option( 'home', $target );
		}
	}

	if ( is_string( $siteurl ) ) {
		$siteurl_clean = untrailingslashit( preg_replace( '#/wp-admin/?$#i', '', $siteurl ) );
		if ( $siteurl_clean !== $target ) {
			update_option( 'siteurl', $target );
		}
	}
}
// add_action( 'init', 'sergiopremium_normalize_site_urls_to_current_host', 6 );
